<?php
$db_host = "ns64.hostgator.mx";
$db_user = "alejan92_elliot";
$db_pass = "Lft79xywim.";
$db_database = "alejan92_imagenes";
